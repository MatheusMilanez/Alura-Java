package bytebankHerdado;

public class EditorDeVideo extends Funcionario{
	public double getBonificacao() {
		System.out.println("Chamando o método de bonificação do Editor de video");
		return 150;
	}
}
