package bytebankHerdado;

//Contrato Autenticavel
	//quem assinar esse contrato,precisa implementar
	//metodo setSenha
	//metodo autentica




public abstract interface Autenticavel  {
//interface não tem nada concreto , só abstact 
	
	public abstract void setSenha(int senha);
	
	public abstract boolean autentica (int senha);
}
