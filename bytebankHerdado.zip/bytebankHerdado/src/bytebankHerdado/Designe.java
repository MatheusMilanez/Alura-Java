package bytebankHerdado;

public class Designe extends Funcionario{
	public double getBonificacao() {
		System.out.println("Chamando o método de bonificação do Designer");
		return 200;
	}
}
