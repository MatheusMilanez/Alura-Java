/**
 * 
 */
/**
 * @author matheus
 *
 */
module bytebankHerdado {
}