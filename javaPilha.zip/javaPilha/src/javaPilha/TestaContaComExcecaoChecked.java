package javaPilha;

public class TestaContaComExcecaoChecked {

	public static void main(String[] args) {
		Conta c = new Conta();
		c.deposita();
	}

}
