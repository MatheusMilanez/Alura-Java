package javaPilha;

public class MinhaExcecao extends RuntimeException{
	
	public MinhaExcecao(String msg) {
		super(msg);
	}
	
	
}
