package Enums;

public class Teste {

	public static void main(String[] args) {
		
		System.out.println(Thread.MAX_PRIORITY);
		System.out.println(Thread.NORM_PRIORITY);
		System.out.println(Thread.MIN_PRIORITY);
		
		Thread t = new Thread(() -> System.out.println("Rodando Thread..."));
		
		Prioridade pMin = Prioridade.MIN;
		Prioridade pNormal = Prioridade.NORMAL;
		Prioridade pMax = Prioridade.MAX;
		
		System.out.println(pMin);
		System.out.println(pNormal);
		System.out.println(pMax);
		
		System.out.println(pMin.name());
		System.out.println(pNormal.name());
		System.out.println(pMax.name());
		
		System.out.println(pMin.ordinal());
		System.out.println(pNormal.ordinal());
		System.out.println(pMax.ordinal());
		
		t.start();
	}

}
