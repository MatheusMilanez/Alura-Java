package Enums;

public enum Prioridade {

	MIN , NORMAL , MAX;
	
	
}
