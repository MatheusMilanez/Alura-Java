package bytebankHerdadoConta;

public interface Tributavel {
	
	public abstract double getValorImposto();

}
